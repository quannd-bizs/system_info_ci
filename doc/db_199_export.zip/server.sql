INSERT INTO server(id,
                   server_id,
                   account_id,
                   name,
                   host,
                   reporting,
                   last_reported_at,
                   update_date)
     VALUES (1,
             '48282183',
             '1625133',
             'BIPVNServer03TestPHPApplication',
             'BIPVNServer03TestPHPApplication',
             TRUE,
             '2017-05-29 09:44:00.0',
             '2017-05-29 16:44:48.0');

INSERT INTO server(id,
                   server_id,
                   account_id,
                   name,
                   host,
                   reporting,
                   last_reported_at,
                   update_date)
     VALUES (2,
             '50911940',
             '1625133',
             'ip-172-31-13-149',
             'ip-172-31-13-149',
             TRUE,
             '2017-05-29 09:44:37.0',
             '2017-05-29 16:44:48.0');

INSERT INTO server(id,
                   server_id,
                   account_id,
                   name,
                   host,
                   reporting,
                   last_reported_at,
                   update_date)
     VALUES (3,
             '51699861',
             '1625133',
             'SVR01T2M_QUANND_AWS_APP',
             'SVR01T2M_QUANND_AWS_APP',
             TRUE,
             '2017-05-30 08:45:02.0',
             '2017-05-30 16:45:57.0');

INSERT INTO server(id,
                   server_id,
                   account_id,
                   name,
                   host,
                   reporting,
                   last_reported_at,
                   update_date)
     VALUES (4,
             '51899256',
             '1625133',
             'BIP-SVR03',
             'BIP-SVR03',
             TRUE,
             '2017-05-31 09:56:40.0',
             '2017-05-31 17:57:57.0');

COMMIT;